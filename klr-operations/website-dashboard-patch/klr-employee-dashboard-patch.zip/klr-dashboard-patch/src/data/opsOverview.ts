// Seed content mirrored from the Operations Command Center (klr-operations)
// so the gated Overview renders standalone with no backend. Replace this module
// with a Supabase / Edge Function fetch once the live pipeline is re-plumbed.

export type Health = "ontrack" | "inreview" | "atrisk" | "blocked" | "completed";
export type Category = "ops" | "digital" | "ai" | "data";

export interface Kpi {
  name: string;
  value: string;
  target: string;
}

export interface Milestone {
  id: string;
  title: string;
  completed: boolean;
  targetDate: string;
}

export interface Initiative {
  id: string;
  title: string;
  category: Category;
  categoryLabel: string;
  health: Health;
  healthLabel: string;
  stageLabel: string;
  progress: number;
  targetDate: string;
  owner: string;
  description: string;
  kpis: Kpi[];
  milestones: Milestone[];
}

export const HEALTH_LABELS: Record<Health, string> = {
  ontrack: "On Track",
  inreview: "In Review",
  atrisk: "At Risk",
  blocked: "Blocked",
  completed: "Completed",
};

export const INITIATIVES: Initiative[] = [
  {
    id: "proj-contractor-foreman",
    title: "Contractor Foreman ERP & PM Rollout",
    category: "ops",
    categoryLabel: "Operational Systems",
    health: "ontrack",
    healthLabel: "On Track",
    stageLabel: "Field QA & Adoption",
    progress: 68,
    targetDate: "2026-09-30",
    owner: "Nick Donatelli (Operations Lead)",
    description:
      "Full enterprise implementation of Contractor Foreman to replace legacy spreadsheets and disconnected PM tools across all active job sites, superintendents, and trade partners.",
    kpis: [
      { name: "Daily Log Compliance", value: "88%", target: "95%" },
      { name: "Active Field Users", value: "24 / 28", target: "28" },
      { name: "Timecard Sync Accuracy", value: "99.4%", target: "100%" },
      { name: "Open Support Tickets", value: "3", target: "0" },
    ],
    milestones: [
      { id: "m1", title: "Cost Codes, Rate Sheets & Roles Configuration", completed: true, targetDate: "2026-06-15" },
      { id: "m2", title: "Data Migration: Active Projects & Subcontractor Master CRM", completed: true, targetDate: "2026-07-10" },
      { id: "m3", title: "Superintendents & PM Field iPad Workflow Training", completed: true, targetDate: "2026-08-01" },
      { id: "m4", title: "Subcontractor Portal Pilot (5 Priority Trade Partners)", completed: false, targetDate: "2026-08-28" },
      { id: "m5", title: "Final Cutover, Accounting Sync & Legacy Tool Deprecation", completed: false, targetDate: "2026-09-30" },
    ],
  },
  {
    id: "proj-company-website",
    title: "Next-Gen Corporate Website & Digital Asset Hub",
    category: "digital",
    categoryLabel: "Digital & Brand Assets",
    health: "inreview",
    healthLabel: "In Review",
    stageLabel: "Pre-Launch Review",
    progress: 85,
    targetDate: "2026-09-15",
    owner: "Nick Donatelli (Digital Assets Specialist)",
    description:
      "Modern, high-converting corporate web overhaul showcasing luxury residential and commercial builds with project galleries, video case studies, estimate calculators, and local SEO schema.",
    kpis: [
      { name: "Lighthouse Performance", value: "98 / 100", target: "95+" },
      { name: "Case Studies Uploaded", value: "16 / 16", target: "16" },
      { name: "Core Web Vitals LCP", value: "0.85s", target: "< 1.2s" },
      { name: "Target Inbound Lead Uplift", value: "+45%", target: "+35%" },
    ],
    milestones: [
      { id: "m1", title: "Brand Guidelines, Typography & Component Library in Figma", completed: true, targetDate: "2026-06-30" },
      { id: "m2", title: "4K Architectural Drone & Interior Photo Library Ingestion", completed: true, targetDate: "2026-07-20" },
      { id: "m3", title: "Responsive Web Build & Lead Capture Funnel Setup", completed: true, targetDate: "2026-08-10" },
      { id: "m4", title: "Local Schema Markup & Multi-County SEO Citations Audit", completed: false, targetDate: "2026-08-25" },
      { id: "m5", title: "Executive Sign-Off, SSL Verification & DNS Production Switch", completed: false, targetDate: "2026-09-15" },
    ],
  },
  {
    id: "proj-frontdesk-ai",
    title: "Frontdesk AI 24/7 Phone Receptionist & Triage",
    category: "ai",
    categoryLabel: "AI & Automations",
    health: "ontrack",
    healthLabel: "On Track",
    stageLabel: "Voice Tuning & Testing",
    progress: 74,
    targetDate: "2026-09-05",
    owner: "Nick Donatelli (Operations Lead)",
    description:
      "Autonomous voice AI receptionist answering 24/7 inbound phone inquiries, qualifying prospective build clients, providing FAQs, and routing emergency job-site subcontractor calls.",
    kpis: [
      { name: "After-Hours Lead Recovery", value: "94%", target: "90%" },
      { name: "Lead Qualification Accuracy", value: "96%", target: "95%" },
      { name: "Avg Voice Response Latency", value: "680ms", target: "< 750ms" },
      { name: "Monthly AI Minutes Handled", value: "420 min", target: "500 min" },
    ],
    milestones: [
      { id: "m1", title: "Knowledge Base & Conversational Flow Architecture", completed: true, targetDate: "2026-07-15" },
      { id: "m2", title: "Voice Agent Prompt Tuning & Latency Benchmarks", completed: true, targetDate: "2026-07-28" },
      { id: "m3", title: "Emergency Subcontractor Routing & SMS Webhook Alerts", completed: true, targetDate: "2026-08-08" },
      { id: "m4", title: "Live Forwarding Overflow Beta Test (100 Inbound Calls)", completed: false, targetDate: "2026-08-22" },
      { id: "m5", title: "Full 24/7 Primary Phone Line Deployment & CRM Auto-Sync", completed: false, targetDate: "2026-09-05" },
    ],
  },
  {
    id: "proj-permit-tracker",
    title: "County-Wide Building Permit Intelligence Feed",
    category: "data",
    categoryLabel: "Data & Intelligence",
    health: "atrisk",
    healthLabel: "At Risk",
    stageLabel: "Connector Ingestion Patch",
    progress: 55,
    targetDate: "2026-10-15",
    owner: "Nick Donatelli (Data & Assets Lead)",
    description:
      "Scheduled daily automated data pipeline ingesting newly issued municipal & county building permits (custom residential, commercial remodels) to power market intelligence and high-value lead acquisition.",
    kpis: [
      { name: "Weekly Permits Ingested", value: "184 / wk", target: "200 / wk" },
      { name: "High-Valuation Leads ($500k+)", value: "42", target: "50 / mo" },
      { name: "Ingestion Pipeline Uptime", value: "96.2%", target: "99%" },
      { name: "Data Extraction Accuracy", value: "99.1%", target: "98%" },
    ],
    milestones: [
      { id: "m1", title: "County Building Dept Schema Mapping & Field Extraction", completed: true, targetDate: "2026-07-05" },
      { id: "m2", title: "Automated Ingestion Scraper & Scheduled Cron Runner", completed: true, targetDate: "2026-07-25" },
      { id: "m3", title: "Patch County Portal Cloudflare/Captcha Authentication Update", completed: false, targetDate: "2026-08-30" },
      { id: "m4", title: "Lead Scoring Engine & High-Valuation Alert Filter ($250k+)", completed: false, targetDate: "2026-09-20" },
      { id: "m5", title: "Weekly Executive Digest & Sales Dispatch Integration", completed: false, targetDate: "2026-10-15" },
    ],
  },
];

export interface ExecutiveStats {
  total: number;
  onTrack: number;
  inReview: number;
  atRisk: number;
  blocked: number;
  completedMilestones: number;
  totalMilestones: number;
  milestoneRate: number;
}

// Derived from INITIATIVES so the KPI bar stays correct if the seed data
// changes or is swapped for a live source.
export function getExecutiveStats(initiatives: Initiative[] = INITIATIVES): ExecutiveStats {
  const totalMilestones = initiatives.reduce((sum, i) => sum + i.milestones.length, 0);
  const completedMilestones = initiatives.reduce(
    (sum, i) => sum + i.milestones.filter((m) => m.completed).length,
    0,
  );
  const countHealth = (h: Health) => initiatives.filter((i) => i.health === h).length;

  return {
    total: initiatives.length,
    onTrack: countHealth("ontrack"),
    inReview: countHealth("inreview"),
    atRisk: countHealth("atrisk"),
    blocked: countHealth("blocked"),
    completedMilestones,
    totalMilestones,
    milestoneRate: totalMilestones === 0 ? 0 : Math.round((completedMilestones / totalMilestones) * 100),
  };
}
