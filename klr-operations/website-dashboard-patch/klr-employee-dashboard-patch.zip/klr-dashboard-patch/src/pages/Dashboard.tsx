import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  FolderKanban,
  Zap,
  Activity,
  Target,
  CalendarDays,
  LogOut,
  Lock,
  CheckCircle2,
  Circle,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import {
  INITIATIVES,
  getExecutiveStats,
  type Health,
  type Initiative,
} from "@/data/opsOverview";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";
import klrLogo from "@/assets/klr-logo.jpeg";

// Health -> theme token. Uses the site's warm palette rather than a generic
// admin green/red so the dashboard reads as part of KLR Build.
const HEALTH_STYLES: Record<Health, { dot: string; text: string; bar: string }> = {
  ontrack: { dot: "bg-sage", text: "text-sage", bar: "bg-sage" },
  inreview: { dot: "bg-pool", text: "text-pool", bar: "bg-pool" },
  atrisk: { dot: "bg-terracotta", text: "text-terracotta", bar: "bg-terracotta" },
  blocked: { dot: "bg-destructive", text: "text-destructive", bar: "bg-destructive" },
  completed: { dot: "bg-sage", text: "text-sage", bar: "bg-sage" },
};

const VIEW_TABS = [
  { id: "overview", label: "Overview", live: true },
  { id: "pipeline", label: "Trello Pipeline", live: false },
  { id: "roadmap", label: "Roadmap", live: false },
  { id: "kanban", label: "Kanban", live: false },
  { id: "permits", label: "County Permits", live: false },
] as const;

export default function Dashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [view, setView] = useState<(typeof VIEW_TABS)[number]["id"]>("overview");

  const stats = useMemo(() => getExecutiveStats(INITIATIVES), []);

  async function signOut() {
    await supabase.auth.signOut();
    navigate("/", { replace: true });
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/60 bg-card/60 backdrop-blur-md sticky top-0 z-40">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <img src={klrLogo} alt="KLR Build" className="h-10 w-auto rounded-md" />
            <div className="min-w-0">
              <h1 className="font-display text-lg leading-tight truncate">Operations Command Center</h1>
              <p className="text-xs text-muted-foreground font-body truncate">
                KLR Build • Multi-Initiative Executive Intelligence
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3 shrink-0">
            <span className="hidden sm:inline text-xs text-muted-foreground font-body">{user?.email}</span>
            <Button variant="outline" size="sm" onClick={signOut}>
              <LogOut className="mr-1.5 h-3.5 w-3.5" />
              Sign out
            </Button>
          </div>
        </div>

        {/* View tabs */}
        <div className="container mx-auto px-4">
          <nav className="flex gap-1 overflow-x-auto -mb-px" aria-label="Command Center views">
            {VIEW_TABS.map((tab) => (
              <button
                key={tab.id}
                onClick={() => tab.live && setView(tab.id)}
                disabled={!tab.live}
                className={cn(
                  "relative whitespace-nowrap px-3.5 py-2.5 text-sm font-body border-b-2 transition-colors",
                  view === tab.id
                    ? "border-accent text-foreground"
                    : "border-transparent text-muted-foreground hover:text-foreground",
                  !tab.live && "cursor-not-allowed opacity-60 hover:text-muted-foreground",
                )}
              >
                {tab.label}
                {!tab.live && <Lock className="inline-block ml-1.5 h-3 w-3 align-[-1px]" />}
              </button>
            ))}
          </nav>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        {view === "overview" ? <Overview stats={stats} initiatives={INITIATIVES} /> : null}
      </main>
    </div>
  );
}

function Overview({
  stats,
  initiatives,
}: {
  stats: ReturnType<typeof getExecutiveStats>;
  initiatives: Initiative[];
}) {
  const healthSegments = [
    { key: "ontrack" as Health, count: stats.onTrack, label: "On Track" },
    { key: "inreview" as Health, count: stats.inReview, label: "Review" },
    { key: "atrisk" as Health, count: stats.atRisk, label: "At Risk" },
    { key: "blocked" as Health, count: stats.blocked, label: "Blocked" },
  ].filter((s) => s.count > 0);

  return (
    <div className="space-y-6">
      {/* KPI row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard
          icon={<FolderKanban className="h-4 w-4" />}
          title="Active Initiatives"
          value={String(stats.total)}
          subtext={
            <span className="flex flex-wrap items-center gap-x-2 gap-y-0.5">
              <span className="text-sage">● {stats.onTrack} on track</span>
              <span className="text-terracotta">● {stats.atRisk} at risk</span>
            </span>
          }
        />
        <KpiCard
          icon={<Zap className="h-4 w-4" />}
          title="Milestone Velocity"
          value={`${stats.milestoneRate}%`}
          subtext={`${stats.completedMilestones} of ${stats.totalMilestones} deliverables complete`}
        />
        <KpiCard
          icon={<Activity className="h-4 w-4" />}
          title="Health Distribution"
          value={
            <div className="mt-1 space-y-1.5">
              <div className="flex h-2.5 w-full overflow-hidden rounded-full bg-muted">
                {healthSegments.map((s) => (
                  <div
                    key={s.key}
                    className={HEALTH_STYLES[s.key].bar}
                    style={{ width: `${(s.count / stats.total) * 100}%` }}
                    title={`${s.count} ${s.label}`}
                  />
                ))}
              </div>
              <div className="flex flex-wrap gap-x-3 gap-y-0.5 text-xs font-body font-normal">
                {healthSegments.map((s) => (
                  <span key={s.key} className={cn("flex items-center gap-1", HEALTH_STYLES[s.key].text)}>
                    <span className={cn("h-1.5 w-1.5 rounded-full", HEALTH_STYLES[s.key].dot)} />
                    {s.count} {s.label}
                  </span>
                ))}
              </div>
            </div>
          }
          subtext={stats.blocked > 0 ? `⚠️ ${stats.blocked} blocked` : "Zero active blockers"}
        />
        <KpiCard
          icon={<Target className="h-4 w-4" />}
          title="Role Focus"
          value={<span className="text-xl font-body font-bold text-accent">Ops & Digital Assets</span>}
          subtext="KLR Build Operational Command"
        />
      </div>

      {/* Initiatives */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {initiatives.map((p) => (
          <InitiativeCard key={p.id} initiative={p} />
        ))}
      </div>
    </div>
  );
}

function KpiCard({
  icon,
  title,
  value,
  subtext,
}: {
  icon: React.ReactNode;
  title: string;
  value: React.ReactNode;
  subtext: React.ReactNode;
}) {
  return (
    <Card>
      <CardContent className="pt-5">
        <div className="flex items-center justify-between">
          <span className="text-xs uppercase tracking-wide text-muted-foreground font-body">{title}</span>
          <span className="text-accent">{icon}</span>
        </div>
        <div className="mt-1.5 font-display text-3xl leading-none">{value}</div>
        <div className="mt-2 text-xs text-muted-foreground font-body">{subtext}</div>
      </CardContent>
    </Card>
  );
}

function InitiativeCard({ initiative: p }: { initiative: Initiative }) {
  const next = p.milestones.find((m) => !m.completed);
  const done = p.milestones.filter((m) => m.completed).length;
  const styles = HEALTH_STYLES[p.health];

  return (
    <Card className="flex flex-col">
      <CardHeader className="pb-3">
        <div className="flex flex-wrap items-center gap-2">
          <Badge variant="secondary" className="font-body font-normal">
            {p.categoryLabel}
          </Badge>
          <Badge variant="outline" className={cn("gap-1 font-body font-normal", styles.text)}>
            <span className={cn("h-1.5 w-1.5 rounded-full", styles.dot)} />
            {p.healthLabel}
          </Badge>
        </div>
        <h3 className="font-display text-lg leading-snug mt-2">{p.title}</h3>
        <p className="text-sm text-muted-foreground font-body">{p.description}</p>
      </CardHeader>

      <CardContent className="flex flex-1 flex-col gap-4">
        <div>
          <div className="flex items-center justify-between text-xs font-body mb-1.5">
            <span className="text-muted-foreground">
              Progress ({done}/{p.milestones.length} milestones)
            </span>
            <span className="font-semibold text-accent">{p.progress}%</span>
          </div>
          <Progress value={p.progress} className="h-2" />
        </div>

        <div className="rounded-lg border border-dashed border-border bg-muted/40 px-3 py-2.5">
          <div className="text-[11px] uppercase tracking-wide text-muted-foreground font-body mb-1">
            {next ? "Next critical deliverable" : "Status"}
          </div>
          <div className="flex items-start gap-2 text-sm font-body">
            {next ? (
              <>
                <Circle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                <span>{next.title}</span>
              </>
            ) : (
              <>
                <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-sage" />
                <span className="text-sage">All planned milestones completed</span>
              </>
            )}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2">
          {p.kpis.slice(0, 2).map((kpi) => (
            <div key={kpi.name} className="rounded-lg bg-secondary/50 px-3 py-2">
              <div className="text-[11px] text-muted-foreground font-body truncate" title={kpi.name}>
                {kpi.name}
              </div>
              <div className="font-display text-base">{kpi.value}</div>
            </div>
          ))}
        </div>

        <div className="mt-auto flex items-center gap-1.5 border-t border-border/60 pt-3 text-xs text-muted-foreground font-body">
          <CalendarDays className="h-3.5 w-3.5" />
          Target: <strong className="text-foreground font-semibold">{p.targetDate}</strong>
        </div>
      </CardContent>
    </Card>
  );
}
