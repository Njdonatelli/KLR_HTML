import { ReactNode } from "react";
import { Navigate, useLocation } from "react-router-dom";
import { Loader2, ShieldAlert } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { isEmployeeEmail } from "@/lib/auth/employee";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

interface ProtectedRouteProps {
  children: ReactNode;
}

/**
 * Three-gate guard for employee-only routes:
 *   1. Session present         -> else send to /login?next=<path>
 *   2. Email verified          -> blocks unconfirmed password signups from
 *                                 claiming a @klrbuild.com address they don't own
 *   3. Domain on allowlist     -> the actual "employee-only" rule
 * A signed-in non-employee gets an explicit denial (not a redirect loop) so
 * they understand why they can't proceed and can switch accounts.
 */
export default function ProtectedRoute({ children }: ProtectedRouteProps) {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!user) {
    const next = encodeURIComponent(location.pathname + location.search);
    return <Navigate to={`/login?next=${next}`} replace />;
  }

  // Google OAuth returns a provider-verified email; password signups only get
  // email_confirmed_at once the confirmation link is clicked.
  const emailVerified = Boolean(user.email_confirmed_at);
  const allowed = emailVerified && isEmployeeEmail(user.email);

  if (!allowed) {
    return (
      <main className="min-h-screen flex items-center justify-center bg-background px-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <div className="flex items-center gap-2">
              <ShieldAlert className="h-5 w-5 text-destructive" />
              <CardTitle>Employees only</CardTitle>
            </div>
            <CardDescription>
              {emailVerified
                ? `This area is restricted to KLR Build staff. ${user.email ?? "Your account"} isn't an authorized employee address.`
                : "Confirm your email address first, then reload this page."}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button
              variant="outline"
              className="w-full"
              onClick={async () => {
                await supabase.auth.signOut();
                window.location.href = "/login?next=/dashboard";
              }}
            >
              Sign in with a different account
            </Button>
          </CardContent>
        </Card>
      </main>
    );
  }

  return <>{children}</>;
}
