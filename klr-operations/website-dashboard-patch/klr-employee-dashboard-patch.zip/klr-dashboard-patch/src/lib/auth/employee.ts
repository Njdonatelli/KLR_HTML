// Employee access is gated by verified email domain. Kept as a data array so
// adding a second brand/domain later is a one-line edit, not a logic change.
export const ALLOWED_EMPLOYEE_DOMAINS = ["klrbuild.com"] as const;

type AllowedDomain = (typeof ALLOWED_EMPLOYEE_DOMAINS)[number];

/**
 * True only for a non-empty email whose domain is on the allowlist.
 * Domain match is case-insensitive; callers must separately confirm the
 * email is verified (see ProtectedRoute) so the domain can't be spoofed on
 * an unconfirmed password signup.
 */
export function isEmployeeEmail(email?: string | null): boolean {
  if (!email) return false;
  const domain = email.split("@")[1]?.toLowerCase().trim();
  return !!domain && (ALLOWED_EMPLOYEE_DOMAINS as readonly string[]).includes(domain as AllowedDomain);
}
